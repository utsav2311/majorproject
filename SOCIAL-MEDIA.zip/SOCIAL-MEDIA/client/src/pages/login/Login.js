import React, { useState } from "react";
import "./Login.scss";
import { Link, useNavigate } from "react-router-dom";
import { axiosClient } from "../../utils/axiosClient";
import { KEY_ACCESS_TOKEN, setItem } from "../../utils/localStorageManager";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();

    if (!email || !password) {
      alert("Please enter both email and password.");
      return;
    }

    try {
      const response = await axiosClient.post("/auth/login", {
        email,
        password,
      });

      console.log("Login Response:", response); // Debugging

      if (response?.result?.accessToken) {
        setItem(KEY_ACCESS_TOKEN, response?.result?.accessToken); // Fixed
        navigate("/"); // Navigate to home on successful login
      } else {
        alert("Login failed. Please try again."); // Fallback case
      }
    } catch (error) {
      console.log("Login error:", error); // Log error for debugging
      alert(
        error?.response?.data?.message ||
          "Something went wrong. Please try again."
      );
    }
  }

  return (
    <div className="Login">
      <div className="login-box">
        <h2 className="heading">Login</h2>
        <form onSubmit={handleSubmit}>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            className="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label htmlFor="password">Password</label>
          <input
            type="password"
            className="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <input type="submit" className="submit" value="Log In" />
        </form>
        <p className="subheading">
          Do not have an account? <Link to="/signup">Sign Up</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
